import java.util.*;
import java.io.*;
public class Main1 {
	public static void main(String[] args) throws FileNotFoundException{
		File file = new File("DATA12.txt");
		Scanner in = new Scanner(file);
		while(in.hasNext()){
			String word = new String();
			word = in.nextLine();
			int wordLength = word.length();
			int out = wordLength - 1;
			char test = ' ';
			for(int i = 0;i<wordLength;i++){
				if(test != word.charAt(i)){
				try{
					if(word.charAt(i) == word.charAt(i+1)){
						ArrayList<Character> temp1 = new ArrayList<Character>();
						ArrayList<Character> temp2 = new ArrayList<Character>();
						if(i+1<=wordLength/2){
							boolean equal = true;
							for(int j = 0;j<i+1;j++){
								temp1.add(word.charAt(i-j));
								temp2.add(word.charAt(i+j+1));
								if(temp1.get(j) != temp2.get(j)){
									j=i+1;
									equal = false;
								}
							}
							
							if((equal)&&(out > wordLength - (2*(i+1)))) out = wordLength - (2*(i+1));
						}else{
							boolean equal = true;
							for(int j = 0;j<wordLength-i-1;j++){
								temp1.add(word.charAt(i-j));
								temp2.add(word.charAt(i+j+1));
								if(temp1.get(j) != temp2.get(j)){
									j=wordLength;
									equal = false;
								}
							}
							if((equal)&&(out > wordLength - (2*(wordLength-i-1))))out = wordLength - (2*(wordLength-i-1));
						}
						
						/*if(word.substring(0,i).equals(word.substring(i+1,i*2+1))){
							out = wordLength - (2*(i+1));
						}else if(word.substring(wordLength-1,i+1).equals(word.substring(i,i-(wordLength-2-i)))){
							out = wordLength - (2*(wordLength-i));
						}*/
					}else if(word.charAt(i-1) == word.charAt(i+1)){
						ArrayList<Character> temp1 = new ArrayList<Character>();
						ArrayList<Character> temp2 = new ArrayList<Character>();
						if(i+1<=wordLength/2){
							boolean equal = true;
							for(int j = 0;j<i;j++){
								temp1.add(word.charAt(i-j-1));
								temp2.add(word.charAt(i+j+1));
								if(temp1.get(j) != temp2.get(j)){
									j=i;
									equal = false;
								}
							}
							
							if((equal)&&(out > wordLength - (2*i) - 1)) out = wordLength - (2*i) - 1;
						}else{
							boolean equal = true;
							for(int j = 0;j<wordLength-i-1;j++){
								temp1.add(word.charAt(i-j-1));
								temp2.add(word.charAt(i+j+1));
								if(temp1.get(j) != temp2.get(j)){
									j=wordLength;
									equal = false;
								}
							}
							
							if((equal)&&(out > wordLength - (2*(wordLength-i-1))-1))out = wordLength - (2*(wordLength-i-1))-1;
						}
						/*if(word.substring(0,i).equals(word.substring(i,i*2))){
							out = wordLength - (2*i) - 1;
						}else if(word.substring(wordLength-1,i).equals(word.substring(i,i-(wordLength-1-i)))){
							out = wordLength - (2*(wordLength-i+2))-1;
						}*/
					}
				}catch(Exception e){
					
				}finally{
				}
				}
				test = word.charAt(i);
			}
			System.out.println(out);
			
			
		}		
	}
}
